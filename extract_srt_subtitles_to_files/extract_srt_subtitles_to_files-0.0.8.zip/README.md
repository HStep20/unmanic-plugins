# Extract text subtitle streams to SRT files

plugin for [Unmanic](https://github.com/Unmanic)
