
**<span style="color:#56adda">0.0.8</span>**
- Add library tester to search for files with SRT streams
- Update FFmpeg helper

**<span style="color:#56adda">0.0.7</span>**
- Update FFmpeg helper
- Add platform declaration

**<span style="color:#56adda">0.0.6</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.5</span>**
- Fix bug in stream mapping causing subtitles from the previous file being added to the command of the current file

**<span style="color:#56adda">0.0.4</span>**
- Limit plugin to only process files with a "video" mimetype
- Remove support for older versions of Unmanic (requires >= 0.1.0)
- Fix issue when creating SRT file naming (TypeError: expected string or bytes-like object)
- Add better debug logging

**<span style="color:#56adda">0.0.3</span>**
- Fix import issue in plugin file

**<span style="color:#56adda">0.0.2</span>**
- Update Plugin for Unmanic v1 PluginHandler compatibility
- Update icon

**<span style="color:#56adda">0.0.1</span>**
- Initial version
