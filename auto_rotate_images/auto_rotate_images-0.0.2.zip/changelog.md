
**<span style="color:#56adda">0.0.2</span>**
- Add description
- Add checks to ensure dependencies are installed and log error if not

**<span style="color:#56adda">0.0.1</span>**
- Initial version
