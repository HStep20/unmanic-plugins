
**<span style="color:#56adda">0.0.5</span>**
- Fix issue with the replace of {source_file_size}

**<span style="color:#56adda">0.0.4</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.3</span>**
- FIX: The format_map function can cause issues with some command or arg strings

**<span style="color:#56adda">0.0.2</span>**
- Refactor for Unmanic v1 PluginHandler compatibility

**<span style="color:#56adda">0.0.1</span>**
- initial version
