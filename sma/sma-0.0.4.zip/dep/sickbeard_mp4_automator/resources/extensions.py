valid_poster_extensions = ['jpg', 'png']
tmdb_api_key = "45e408d2851e968e6e4d0353ce621c66"
subtitle_codec_extensions = {'srt': 'srt',
                             'webvtt': 'vtt',
                             'ass': 'ass',
                             'pgs': 'sup',
                             'hdmv_pgs_subtitle': 'sup',
                             'dvdsub': 'mks',
                             'dvb_subtitle': 'mks',
                             'dvd_subtitle': 'mks'}
bad_post_files = ['resources', '.DS_Store']
bad_post_extensions = ['.txt', '.log', '.pyc']
