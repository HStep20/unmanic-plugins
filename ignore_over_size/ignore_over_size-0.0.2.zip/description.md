
Sizes can be written as:

- Bytes (Eg. '<span style="color:blue">50</span>' or '<span style="color:blue">800 B</span>')
- Kilobytes (Eg. '<span style="color:blue">100KB</span>' or '<span style="color:blue">23 K</span>')
- Megabytes (Eg. '<span style="color:blue">9M</span>' or '<span style="color:blue">34 MB</span>')
- Gigabytes (Eg. '<span style="color:blue">4GB</span>')
- Terabytes (Eg. '<span style="color:blue">1 TB</span>')
- Petabytes (Eg. '<span style="color:blue">0.5PB</span>')
- etc...
