
**<span style="color:#56adda">0.0.7</span>**
- Update FFmpeg helper
- Add platform declaration

**<span style="color:#56adda">0.0.6</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.5</span>**
- Limit plugin to only process files with a "video" or "audio" mimetypes
- Add support for audio trimming
- Record files that have been trimmed. By default, don't trim them again.

**<span style="color:#56adda">0.0.4</span>**
- Update for compatibility with new Unmanic version

**<span style="color:#56adda">0.0.3</span>**
- Added missing license file and header.
- Updated icon URL

**<span style="color:#56adda">0.0.2</span>**
- Fixed bug - if a file had multiple audio streams, this plugin was copying only one.
- Fixed bug - under some conditions, the input buffer limit would be reached.
- Fixed bug - Plugin could not support MP4 files with trueHD streams.

**<span style="color:#56adda">0.0.1</span>**
- Initial version
