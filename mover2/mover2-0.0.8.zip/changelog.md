
**<span style="color:#56adda">0.0.8</span>**
- Always prevent Unmanic's default move process (Requires Unmanic v0.2.0)

**<span style="color:#56adda">0.0.7</span>**
- Fixed bug where library path was not being correctly fetched on newer versions of Unmanic

**<span style="color:#56adda">0.0.6</span>**
- Always exclude the '.unmanic' file from file movements
- Disable the default file copy of Unmnaic's post-processor when Remove source files is unselected (Requires Unmanic v0.2.0)

**<span style="color:#56adda">0.0.5</span>**
- Ignore files on all future scans if "Remove source files" is not selected
- Add ability to force tasks to be created for all files tested regardless of other plugin processing requirements

**<span style="color:#56adda">0.0.4</span>**
- Enabled support for v2 plugin executor

**<span style="color:#56adda">0.0.3</span>**
- Ensure the file copy flag is set for the file moments. Even tho the current default is to do so it may change in the future.

**<span style="color:#56adda">0.0.2</span>**
- Update available options with the ability to recreate directory structure relative to the library path

**<span style="color:#56adda">0.0.1</span>**
- initial version based on the original mover plugin by R3dC4p and 
  updated for compatibility with latest Unmanic release
