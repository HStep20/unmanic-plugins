
**<span style="color:#56adda">0.0.8</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.7</span>**
- Fix issue with number formatting
- Add support for parsing data for tasks processed with remote workers

**<span style="color:#56adda">0.0.6</span>**
- Remove migrations of legacy Unmanic historic data as it still causes intermittent issues
- More improvements to plugin's database connection

**<span style="color:#56adda">0.0.5</span>**
- Improvements to plugin's database connection

**<span style="color:#56adda">0.0.4</span>**
- Fix issue where the Plugin's database was being locked by multiple workers attempting to update at the same time

**<span style="color:#56adda">0.0.3</span>**
- Fix exception and rollback of DB transaction.

**<span style="color:#56adda">0.0.2</span>**
- Set initial flow priority to high

**<span style="color:#56adda">0.0.1</span>**
- Initial version
