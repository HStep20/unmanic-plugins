
**<span style="color:#56adda">0.0.5</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.4</span>**
- Update Plugin for Unmanic v1 PluginHandler compatibility
- Update icon
- Improve description with more regex examples

**<span style="color:#56adda">0.0.3</span>**
- Update icon link

**<span style="color:#56adda">0.0.2</span>**
- Fix issue with settings not showing as a textarea input

**<span style="color:#56adda">0.0.1</span>**
- Initial version
